LAB=traps
